class Evaluator:
    def evaluate(self, secret_code: str, guess:str)-> tuple:
        """ Calls and returns exact and partial matches per guess. """
        exact_matches, exact_matches_dict = self.count_exact(secret_code, guess)
        partial_matches = self.count_partial(secret_code, guess, exact_matches_dict)
        return exact_matches, partial_matches


    def count_exact(self, secret_code: str, guess:str)-> tuple:
        """ Count the number of exact matches between secret code and guess"""
        exact_matches = 0
        exact_matches_list = []
        for i,char in enumerate(guess): # access the current index in the guess
            if char in secret_code: # if there is a match, check if it's exact
                match_count = secret_code.count(char) # amount of times the guessed number is in the secret code
                code_index = secret_code.find(char) # the index of the guessed number in the secret code
                if match_count > 1: # special case if the number appears more than once - .find() will only find the first index
                    if code_index == i:
                        exact_matches += 1
                        exact_tuple =i, char
                        exact_matches_list.append(exact_tuple)
                    for _ in range(match_count-1): # don't need to do a special iteration for the first one - no need to change the index
                        new_index = secret_code.find(char, code_index+1) # calculates the next index of the number by starting one after the previous index
                        if new_index == i: # exact match
                            exact_matches += 1
                            exact_tuple = i, char
                            exact_matches_list.append(exact_tuple)
                        code_index = new_index
                else: # case if the number appears only once
                    if code_index == i:
                        exact_matches += 1
                        exact_tuple = i, char
                        exact_matches_list.append(exact_tuple)
        return exact_matches, exact_matches_list

    def count_partial(self, secret_code: str, guess:str, exact_matches_list)-> int:
        partial_matches = 0
        matches = [char for char in guess if char in secret_code]
        exact_chars = [char for i, char in exact_matches_list]
        for char in matches:
            if char not in exact_chars:
                partial_matches += 1
        return partial_matches