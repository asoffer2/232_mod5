import code
import random

class Code:
    def __init__(self):
        self.code = self.generate_code()

    def generate_code(self) -> str:
        """Generates a 4-digit code"""
        curr_code = ""
        for _ in range(4):
            num = random.randint(0, 9)
            curr_code += str(num)
        return curr_code

    def get_code(self) -> str:
        return self.code

    def __str__(self) -> str:
        return f"{self.code}"