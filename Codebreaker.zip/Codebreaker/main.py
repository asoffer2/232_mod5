from Game import Game
from Evaluator import Evaluator
from Code import Code
from Player import Player

def main():
    """Pulls together classes into a functional game"""
    guesses = []
    my_player = Player(guesses, 0)
    my_evaluator = Evaluator()
    my_code = Code()
    my_game = Game(my_player, my_evaluator, my_code, 8)
    #print(my_code.code) - remove # to print the code before to test
    print("Welcome to Mastermind!")
    print("---------------------")
    print("|||||||||||||||||||||")
    user_input = " "
    while user_input != "":
        user_input = input("Press any key to start, and enter to to quit ").strip()
        print()
        if user_input == "":
            print("Game over")
            break
        else:
            my_game.play()
            print()

    print("||||||||||||||||||||||")

if __name__ == "__main__":
    main()
