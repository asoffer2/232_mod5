class Evaluator:
    def evaluate(self, secret_code: str, guess: str) -> tuple:
        """Runs the methods to calculate partial and exact matches."""
        exact_matches, used_secret, used_guess = self.count_exact(secret_code, guess)
        partial_matches = self.count_partial(secret_code, guess, used_secret, used_guess)
        return exact_matches, partial_matches


    def count_exact(self, secret_code: str, guess: str) -> tuple:
        """counts exact matches, ensuring no numbers guessed are used twice in the code using placeholders."""
        exact_matches = 0
        # create placeholders for numbers guessed
        used_secret = [False] * len(secret_code)
        used_guess = [False] * len(guess)

        for i in range(len(guess)):
            if guess[i] == secret_code[i]:
                exact_matches += 1
                used_secret[i] = True
                used_guess[i] = True

        return exact_matches, used_secret, used_guess


    def count_partial(self, secret_code: str, guess: str, used_secret, used_guess) -> int:
        """Counts partial matches as matches that are not exact."""
        partial_matches = 0

        for i in range(len(guess)):
            if used_guess[i]:
                continue  # skip exact matches

            for j in range(len(secret_code)):
                if used_secret[j]:
                    continue  # already used in exact

                if guess[i] == secret_code[j]:
                    partial_matches += 1
                    used_secret[j] = True
                    break

        return partial_matches

