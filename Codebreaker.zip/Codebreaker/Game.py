from Player import Player
from Evaluator import Evaluator
from Code import Code

class Game:
    def __init__(self, player: Player, evaluator: Evaluator, secret_code: Code, max_attempts:int ):
        self.player = player
        self.evaluator = evaluator
        self.secret_code = secret_code
        self.max_attempts = max_attempts

    def play(self):
        """Creates a play loop that exits when won/lost."""
        while not self.check_loss():
            print(f"Previous Guesses: {self.player.guesses}")
            exact_matches = self.process_turn()
            if self.check_win(exact_matches):
                print("You won!")
                break
            elif self.check_loss():
                print("You lost!")
                print(f"Code was: {self.secret_code}")
                break


    def process_turn(self) -> int:
        """Stores guesses and processes all turns. """
        guess = self.player.make_guess()
        self.player.store_guess(guess)
        code = self.secret_code.code
        exact_matches, partial_matches = self.evaluator.evaluate(code, guess)
        print(f"Exact_matches: {exact_matches}, Partial_matches: {partial_matches}")
        self.player.attempts_used += 1
        return exact_matches

    def check_win(self, exact_matches: int) -> bool:
        """Returns true if player won the game."""
        if exact_matches == 4:
            return True
        return False

    def check_loss(self):
        """Returns true if player lost."""
        if self.player.attempts_used >= self.max_attempts:
            return True
        return False