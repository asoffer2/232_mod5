class Player:
    def __init__(self, guesses: list, attempts_used:int):
        self.guesses = guesses
        self.attempts_used = attempts_used

    def make_guess(self):
        """Prompt the user to make a guess and validates it."""
        while True:
            raw_user_guess = input("Guess a secret code (4 digits): ").strip()
            if len(raw_user_guess) != 4:
                print("Please enter a four digit code")
                continue
            try:
                user_guess = int(raw_user_guess)
            except ValueError:
                print("Please enter only integers")
                continue
            break

        string_guess = str(user_guess)
        return string_guess

    def store_guess(self, guess:str):
        self.guesses.append(guess)

    def get_attempts_used(self) -> int:
        return self.attempts_used