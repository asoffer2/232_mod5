from deck import Deck
from participent import Participant
from hand import Hand

class Dealer(Participant):
    def __init__(self,name: str,hand: Hand):
        """Initializes a new dealer inheriting from Participent."""
        super().__init__(name, hand)

    def show_first_card(self):
        """Shows only the dealers first card."""
        my_card = self.hand.cards[0]
        return str(my_card)

    def take_turn(self, deck: Deck):
        """Takes one turn for the dealer - this turn will run automatically after the player."""
        print(f"Dealer's hand: {self.hand.show_hand()}") # reveals the dealer's full hand
        # rule of blackjack, dealer must take a card if hos total is less than 17
        while self.hand.get_total() < 17:
            deck.shuffle()
            my_card = deck.deal_card()
            self.take_card(my_card)
            # dealer must stand if greater or equal to 17
            if self.hand.get_total() >= 17:
                return None
        return None