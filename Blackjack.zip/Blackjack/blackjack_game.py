from deck import Deck
from player import Player
from dealer import Dealer

class BlackjackGame:
    """Initializes the Blackjack game."""
    def __init__(self,deck: Deck, player: Player, dealer: Dealer, player_name: str):
        self.deck = deck
        self.player = player
        self.dealer = dealer
        self.player_name = player_name

    def initial_deal(self):
        """Deals two cards to the player and dealer."""
        self.deck.shuffle()
        # deals 2 random cards to each
        for i in range(2):
            player_card = self.deck.deal_card()
            self.player.hand.cards.append(player_card)
            dealer_card = self.deck.deal_card()
            self.dealer.hand.cards.append(dealer_card)


    def show_game_state(self):
        """Shows player their hand, total, cards remaining and the dealers flipped card."""
        print(f"{self.player_name}'s hand: {self.player.hand.show_hand()}")
        print(f"Your total: {self.player.hand.get_total()}")
        dealer_flipped_card = self.dealer.hand.cards[0]
        print()
        print(f"Dealer's flipped card: {str(dealer_flipped_card)}")
        remaining_cards = self.deck.cards_remaining()
        print(f"Remaining cards: {remaining_cards}")

    def determine_winner(self):
        """Determines the winner of the game."""
        if self.player.hand.get_total() > 21: # player busts, winner is dealer
            winner = "dealer"
        elif self.dealer.hand.get_total() > 21: # dealer busts, winner is player
            winner = "player"
        else:
            # if no one busts, higher total wins
            if self.player.hand.get_total() > self.dealer.hand.get_total():
                winner = "player"
            elif self.dealer.hand.get_total() > self.player.hand.get_total():
                winner = "dealer"
            else:
                winner = "push"

        return winner

    def play(self):
        """Plays one full round of blackjack."""
        self.deck.build_deck()
        self.initial_deal()
        self.dealer.show_first_card()
        self.show_game_state()

        self.player.take_turn(self.deck)
        self.show_game_state()

        self.dealer.take_turn(self.deck)
        self.show_game_state()
        winner = self.determine_winner()

        # print dealer's hand s player knows what dealer is doing
        print(f"Dealer's hand: {self.dealer.hand.show_hand()}")
        print(f"Dealer's total: {self.dealer.hand.get_total()}")
        print()
        print(f"Your winner: {winner}")

