from card import Card


class Hand:
    def __init__(self):
        self.cards = []

    def add_card(self, card: Card):
        self.cards.append(card)

    def get_total(self):
        total_value = 0
        for card in self.cards:
            if card.rank == "Ace":
                if total_value + 11 > 21:
                    total_value += 1
                    continue
                else:
                    total_value += 11
                    continue
            value = card.value
            total_value += value
        return total_value

    def show_hand(self):
        cards = "Hand:"
        for card in self.cards:
            curr_str = str(card)
            cards += curr_str
            cards += "\n"

        return cards

    def __str__(self):
        return self.show_hand()

