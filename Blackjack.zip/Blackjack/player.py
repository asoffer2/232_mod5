
from participent import Participant
from hand import Hand
from deck import Deck


class Player(Participant):
    def __init__(self, name: str, hand: Hand):
        super().__init__(name, hand)


    def take_turn(self, deck: Deck):
        user_input = ""
        while user_input != "stand":
            if self.hand.get_total() > 21: # player busts
                print()
                print("------")
                print("Bust")
                print("------")
                return None
            user_input = input("Hit or Stand: ").strip().lower()
            if user_input == "hit":
                deck.shuffle()
                my_card = deck.deal_card()
                self.take_card(my_card)
                print(f"You chose {str(my_card)}")
                print(f"Your total is now {self.hand.get_total()}")
            elif user_input == "stand":
                return None
            elif self.hand.get_total() > 21:
                return None
            else:
                print("Invalid input.")
                continue
        return None
