from hand import Hand
from player import Player
from dealer import Dealer
from deck import Deck
from blackjack_game import BlackjackGame


def main():
    """Pulls together all classes by creating all objects and playing the game."""
    dealer_hand = Hand()
    player_hand = Hand()
    my_deck = Deck()
    player_name = input("Please enter your name: ")
    dealer = Dealer("Dealer", dealer_hand)
    my_player = Player(player_name, player_hand)
    game = BlackjackGame(my_deck, my_player, dealer, player_name)

    while True:
        user_input = input("Do you want to continue? (y/n): ").lower().strip()
        if user_input == "y":
            game.play()
            continue
        break
    print("Thank you for playing!")

if __name__ == "__main__":
    main()
