from hand import Hand
from card import Card
from deck import Deck
from abc import ABC, abstractmethod

class Participant(ABC):
    def __init__(self, name: str, hand: Hand):
        self.name = name
        self.hand = hand

    def take_card(self, card: Card):
        self.hand.cards.append(card)

    def show_hand(self):
        self.hand.show_hand()

    def get_total(self):
        self.hand.get_total()

    def is_busted(self):
        total = self.hand.get_total()
        if total > 21:
            return True
        return False

    @abstractmethod
    def take_turn(self, deck: Deck):
        pass
