from card import Card
import random

VALUES = [1,2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
SUITS = ["Spades", "Clubs", "Diamonds", "Hearts"]
RANKS = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace"]

class Deck:
    def __init__(self):
        self.cards = []
        self.build_deck()
        self.remaining_cards = len(self.cards)

    def build_deck(self):
        for i in range(52): # there are 52 cards in the deck
            suit = random.choice(SUITS)
            rank = random.choice(RANKS)
            if rank == "Ace": # ace can be either 1 or 11
                value = (1, 11)
            elif rank == "King" or rank == "Queen" or rank == "Jack":
                value = 10
            else:
                value = int(rank)
            my_card = Card(suit, rank, value) # creates a randomly generated card
            # add the card if it's not in the deck
            if my_card not in self.cards:
                self.cards.append(my_card)


    def shuffle(self):
        random.shuffle(self.cards)

    def deal_card(self):
        curr_card = self.cards.pop()
        return curr_card

    def cards_remaining(self):
        return self.remaining_cards